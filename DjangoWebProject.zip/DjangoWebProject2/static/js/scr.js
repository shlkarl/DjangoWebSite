﻿function showprod() {
    var popup = document.getElementById("1");
    if (popup.style.display === "none") {
        popup.style.display = "block";
    } else {
        popup.style.display = "none";
    }
}
function showus() {
    var popup = document.getElementById("2");
    if (popup.style.display === "none") {
        popup.style.display = "block";
    } else {
        popup.style.display = "none";
    }
}
function showser() {
    var popup = document.getElementById("3");
    if (popup.style.display === "none") {
        popup.style.display = "block";
    } else {
        popup.style.display = "none";
    }
}

function enter() {
    const popWin = window.open('LK.html', 'LK',
        'top=150, left=100, width=350, height=100')
}

